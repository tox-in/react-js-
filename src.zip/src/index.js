import React from 'react';
import ReactDOM from 'react-dom/client';
// import LoginForm from './components/Login';
import Home from './components/Home';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <div>
{/* <LoginForm  />  */}
<Home  />
</div>
);
reportWebVitals();
