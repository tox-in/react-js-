import React from 'react'
import './Login.css'
import 'bootstrap/dist/css/bootstrap.min.css'


function LoginForm( ) {
    return (
      <div className='wrapper bg-dark d-flex align-items-center justify-content-center w-100'>
      <div className='login '>
        <h2 className='mb-3'>Login Form</h2>
        <form className='needs-validation'>
          <div className='form-group was-validated mb-2'>
          <label htmlFor='email' className='form-label'>Email address</label>
          <br />
          <input type='email' placeholder='Email@gmail.com' className='form-control' required />
          <div className='invalid-feedback'>
            Please Enter your email
          </div>
          </div>
          <br />
          <div className='form-group was-validated mb-2'>
          <label htmlFor='password' className='form-label'>Password</label>
          <br/>
          <input type='password' placeholder='password' className='form-control' required />
          <div className='invalid-feedback'>
            Please Enter your password
          </div>
          </div>
          <br/>
          <div className=' form-group form-check mb-2'>
          <input type='checkbox' className='form-check-input'  />
          <label htmlFor='check' className='form-check-label-label'>Remember me</label>
          </div>
          <br/>
          <button type='submit' className='btn btn-success block  mt-2 '>Login</button>
        </form>
      </div>
      </div>
    )
  }


export default LoginForm