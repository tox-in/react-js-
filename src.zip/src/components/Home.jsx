import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/css/bootstrap-icons.css'

export default function Home() {
  return (
    <div>
    
    </div>
  );
}
