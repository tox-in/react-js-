import React, { Component } from 'react'

class Signup extends Component {
  render() {
    return (
      <>
        
      </>
    )
  }
}

export default Signup
